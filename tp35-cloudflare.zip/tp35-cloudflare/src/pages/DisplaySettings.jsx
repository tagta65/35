import React, { useState } from "react";
import { ArrowRight, SlidersHorizontal } from "lucide-react";
import { Link } from "react-router-dom";
import ZoomControls from "@/components/scanner/ZoomControls";
import TableShell, { Cell } from "@/components/scanner/TableShell";

const ZOOM_KEY = "tp35-zoom";
const SAMPLES = [
  { symbol: "AAPL", price: 341.07, rsi: 55.2, upside: 13.4 },
  { symbol: "NVDA", price: 225.07, rsi: 48.6, upside: 17.7 },
  { symbol: "TSLA", price: 372.11, rsi: 61.3, upside: 9.1 },
];

export default function DisplaySettings() {
  const [zoom, setZoomState] = useState(() => {
    const saved = Number(localStorage.getItem(ZOOM_KEY));
    return saved >= 50 && saved <= 200 ? saved : 100;
  });

  const setZoom = (z) => {
    setZoomState(z);
    localStorage.setItem(ZOOM_KEY, String(z));
  };

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-950 to-slate-900 text-slate-100"
    >
      <div className="mx-auto max-w-3xl space-y-6 px-4 py-6 sm:py-10">
        <div className="flex items-center gap-3">
          <Link
            to="/"
            className="rounded-lg border border-slate-800 bg-slate-900 p-2 text-slate-300 hover:bg-slate-800"
            title="חזרה לסורק"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="flex items-center gap-2 font-heading text-2xl font-bold text-slate-50 sm:text-3xl">
              <SlidersHorizontal className="h-6 w-6 text-emerald-400" />
              הגדרות תצוגה
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              שלוט בגודל הטבלאות כדי שיהיה נוח לצפייה מהירה מהאייפון — ההגדרה
              נשמרת וחלה על כל הטבלאות בסורק.
            </p>
          </div>
        </div>

        <ZoomControls zoom={zoom} onZoomChange={setZoom} />

        <div className="space-y-2">
          <h2 className="text-sm font-semibold text-slate-400">תצוגה מקדימה</h2>
          <TableShell columns={["Sym", "Price", "RSI", "Upside"]} zoom={zoom}>
            {SAMPLES.map((s) => (
              <tr key={s.symbol}>
                <Cell className="rounded-md bg-slate-800/60 font-semibold text-slate-100">
                  {s.symbol}
                </Cell>
                <Cell className="rounded-md bg-slate-900/60 text-slate-200">
                  {s.price.toFixed(2)}
                </Cell>
                <Cell className="rounded-md bg-slate-900/60 text-slate-200">
                  {s.rsi.toFixed(1)}
                </Cell>
                <Cell className="rounded-md bg-[#089981]/40 text-emerald-200">
                  {s.upside.toFixed(1)}%
                </Cell>
              </tr>
            ))}
          </TableShell>
        </div>
      </div>
    </div>
  );
}