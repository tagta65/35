import db from "@/api/localDb";

import React, { useState, useEffect, useRef } from "react";
import { Radar, Loader2 } from "lucide-react";

import ScannerHeader from "@/components/scanner/ScannerHeader";
import ScannerTabs from "@/components/scanner/ScannerTabs";
import KeySettingsDialog from "@/components/scanner/KeySettingsDialog";
import P402Table from "@/components/scanner/P402Table";
import VixFixTable from "@/components/scanner/VixFixTable";
import AnalogTable from "@/components/scanner/AnalogTable";
import SmcTable from "@/components/scanner/SmcTable";
import OrderFlowTable from "@/components/scanner/OrderFlowTable";
import MtfFlowTable from "@/components/scanner/MtfFlowTable";
import MrktEdgeTable from "@/components/scanner/MrktEdgeTable";
import ZoomControls from "@/components/scanner/ZoomControls";
import { recomputeMtfFlow } from "@/lib/mtfFlowLive";

const TABLES = { p402: P402Table, vixfix: VixFixTable, analog: AnalogTable, smc: SmcTable, orderflow: OrderFlowTable, mtfflow: MtfFlowTable, mrktedge: MrktEdgeTable };

export default function Home() {
  const [tab, setTab] = useState("p402");
  const [timeframe, setTimeframe] = useState("D");
  const [scans, setScans] = useState({});
  const [livePrices, setLivePrices] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [list, setList] = useState(() =>
    localStorage.getItem("tp35-list") === "2" ? "2" : "1"
  );
  const [zoom, setZoom] = useState(() => {
    const saved = Number(localStorage.getItem("tp35-zoom"));
    return saved >= 50 && saved <= 200 ? saved : 100;
  });
  const updateZoom = (z) => {
    setZoom(z);
    localStorage.setItem("tp35-zoom", String(z));
  };
  const loadingRef = useRef(false);
  const pendingRef = useRef(false);
  const retryCountRef = useRef(0);

  const runScan = async () => {
    if (loadingRef.current) {
      pendingRef.current = true;
      return;
    }
    loadingRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const key = list + ":" + tab;
      // show rows as soon as each batch of symbols arrives instead of waiting for all
      const res = await db.functions.invoke("scanStocks", { algo: tab, timeframe, list }, {
        onPartial: (part) =>
          setScans((prev) => ({
            ...prev,
            [key]: {
              results: prev[key]
                ? part.data.results.map((r) => (r.pending && prev[key].results.find((o) => o.symbol === r.symbol)) || r)
                : part.data.results,
              scannedAt: part.data.scannedAt,
            },
          })),
      });
      setScans((prev) => ({
        ...prev,
        [list + ":" + tab]: { results: res.data.results, scannedAt: res.data.scannedAt },
      }));
      // Auto-retry: rescan when the scan failed or too many symbols came back empty
      const nulls = res.data.results.filter((r) => !r.data).length;
      if (nulls >= 8 && retryCountRef.current < 3) {
        retryCountRef.current += 1;
        setTimeout(() => runScan(), 4000);
      } else {
        retryCountRef.current = 0;
      }
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "שגיאה בסריקה");
      if (retryCountRef.current < 3) {
        retryCountRef.current += 1;
        setTimeout(() => runScan(), 4000);
      }
    } finally {
      loadingRef.current = false;
      setLoading(false);
      if (pendingRef.current) {
        pendingRef.current = false;
        runScan();
      }
    }
  };

  // Live: scan automatically whenever the list, tab or timeframe changes
  useEffect(() => {
    retryCountRef.current = 0;
    runScan();
  }, [list, tab, timeframe]);

  // Live: keep refreshing in the background
  useEffect(() => {
    const ms = timeframe === "D" || timeframe === "W" ? 300000 : 60000;
    const id = setInterval(() => { if (!document.hidden) runScan(); }, ms);
    return () => clearInterval(id);
  }, [timeframe, list]);

  // Live: fast polling of latest trades so the price column ticks in real time
  useEffect(() => {
    let stop = false;
    const fetchLive = async () => {
      try {
        if (document.hidden) return;
        const res = await db.functions.invoke("livePrices", {});
        if (!stop && res.data && res.data.prices) setLivePrices(res.data.prices);
      } catch (e) {
        // best-effort - keep the last known prices
      }
    };
    fetchLive();
    const id = setInterval(fetchLive, 5000);
    return () => {
      stop = true;
      clearInterval(id);
    };
  }, []);

  const handleTabChange = (next) => {
    setTab(next);
    setError(null);
  };

  const handleListChange = (next) => {
    setList(next);
    localStorage.setItem("tp35-list", next);
    setError(null);
  };

  const scan = scans[list + ":" + tab];
  const q = search.trim().toUpperCase();
  const results = scan
    ? scan.results
        .map((r) => {
          const p = livePrices[r.symbol];
          if (!r.data || !p) return r;
          if (r.liveBars) {
            const fresh = recomputeMtfFlow(r.liveBars, p);
            return fresh ? { ...r, data: fresh } : r;
          }
          return { ...r, data: { ...r.data, price: p } };
        })
        .filter((r) => !q || r.symbol.includes(q))
    : [];
  const Table = TABLES[tab];

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-950 to-slate-900 text-slate-100"
    >
      <div className="mx-auto max-w-6xl space-y-5 px-4 py-6 sm:py-10">
        <ScannerHeader
          timeframe={timeframe}
          onTimeframeChange={setTimeframe}
          search={search}
          onSearch={setSearch}
          scannedAt={scan?.scannedAt}
          count={scan?.results?.length ?? 0}
          loading={loading}
          onOpenSettings={() => setSettingsOpen(true)}
          list={list}
          onListChange={handleListChange}
        />

        <ScannerTabs tab={tab} onTabChange={handleTabChange} />

        {error && (
          <div className="rounded-xl border border-red-900/60 bg-red-950/50 px-4 py-3 text-sm text-red-300">
            {error}
          </div>
        )}

        {scan && results.length > 0 && (
          <ZoomControls zoom={zoom} onZoomChange={updateZoom} />
        )}

        {loading && scan && (
          <div className="flex items-center gap-2 text-xs text-emerald-300">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            מנסה לטעון נתונים שוב...
          </div>
        )}

        {scan ? (
          results.length ? (
            <Table results={results} zoom={zoom} />
          ) : (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/60 px-4 py-10 text-center text-slate-400">
              לא נמצאו מניות שתואמות לחיפוש
            </div>
          )
        ) : loading ? (
          <div className="flex items-center justify-center gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 px-4 py-16 text-slate-300">
            <Loader2 className="h-5 w-5 animate-spin text-emerald-400" />
            סורק את 35 המניות...
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 px-6 py-16 text-center">
            <Radar className="mx-auto h-10 w-10 text-slate-600" />
            <p className="mt-3 text-slate-400">
              הסריקה מתחילה אוטומטית — בחר טווח זמן או החלף טבלה
            </p>
          </div>
        )}
      </div>

      <KeySettingsDialog
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        onSaved={runScan}
      />
    </div>
  );
}
