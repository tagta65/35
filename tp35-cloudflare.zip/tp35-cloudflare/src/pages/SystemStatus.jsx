import db from "@/api/localDb";

import { useState, useEffect, useCallback } from "react";
import { ArrowRight, RefreshCw, CheckCircle2, XCircle, Clock, Database, Wifi } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const TF_LABELS = { "15": "15 דק'", "30": "30 דק'", "60": "שעה", "120": "שעתיים", "240": "4 שעות", "D": "יומי", "W": "שבועי" };

function StatusBadge({ ok, okText = "תקין", failText = "תקלה" }) {
  return ok ? (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-800 bg-emerald-950/60 px-2.5 py-1 text-xs font-medium text-emerald-300">
      <CheckCircle2 className="h-3.5 w-3.5" />
      {okText}
    </span>
  ) : (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-red-900 bg-red-950/60 px-2.5 py-1 text-xs font-medium text-red-300">
      <XCircle className="h-3.5 w-3.5" />
      {failText}
    </span>
  );
}

function Card({ icon: Icon, title, children }) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 sm:p-5">
      <div className="mb-3 flex items-center gap-2">
        <Icon className="h-4 w-4 text-emerald-400" />
        <h2 className="text-sm font-semibold text-slate-200">{title}</h2>
      </div>
      {children}
    </div>
  );
}

function fmtAge(min) {
  if (min === null || min === undefined) return "—";
  if (min < 60) return `${min} דק'`;
  if (min < 1440) return `${Math.round(min / 60)} שע'`;
  return `${Math.round(min / 1440)} ימים`;
}

export default function SystemStatus() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await db.functions.invoke("systemStatus", {});
      setStatus(res.data);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "שגיאה בבדיקת הסטטוס");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 60000);
    return () => clearInterval(id);
  }, [load]);

  const conn = status?.connectivity;

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-950 to-slate-900 text-slate-100">
      <div className="mx-auto max-w-3xl space-y-5 px-4 py-6 sm:py-10">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Button asChild variant="outline" size="icon" className="border-slate-700 bg-slate-900 hover:bg-slate-800">
              <Link to="/">
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <div>
              <h1 className="font-heading text-2xl font-bold tracking-tight text-slate-50 sm:text-3xl">
                סטטוס מערכת
              </h1>
              <p className="text-sm text-slate-400">תקינות החיבור ל-Alpaca וזמינות הנתונים</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={load}
            disabled={loading}
            className="border-slate-700 bg-slate-900 hover:bg-slate-800"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            רענן
          </Button>
        </div>

        {error && (
          <div className="rounded-xl border border-red-900/60 bg-red-950/50 px-4 py-3 text-sm text-red-300">
            {error}
          </div>
        )}

        {loading && !status && (
          <div className="flex items-center justify-center gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 px-4 py-16 text-slate-300">
            <RefreshCw className="h-5 w-5 animate-spin text-emerald-400" />
            בודק את המערכת...
          </div>
        )}

        {status && (
          <>
            <Card icon={Wifi} title="חיבור לבורסה (Alpaca)">
              <div className="flex flex-wrap items-center gap-2">
                <StatusBadge ok={conn?.ok} okText="מחובר" failText="לא מחובר" />
                <StatusBadge ok={status.keys?.ok} okText={`מפתחות: ${status.keys?.source === "saved" ? "שמורים באפליקציה" : "כספת"}`} failText="חסרים מפתחות" />
                {conn?.feed && (
                  <span className="rounded-full border border-slate-700 bg-slate-800 px-2.5 py-1 text-xs text-slate-300">
                    פיד: {conn.feed.toUpperCase()}
                  </span>
                )}
              </div>
              {conn?.ok ? (
                <p className="mt-3 flex items-center gap-2 text-sm text-slate-400">
                  <Clock className="h-4 w-4 text-slate-500" />
                  נר דקה אחרון:{" "}
                  {conn.lastBarIso
                    ? new Date(conn.lastBarIso).toLocaleString("he-IL")
                    : "—"}{" "}
                  (לפני {fmtAge(conn.ageMin)})
                </p>
              ) : (
                <p className="mt-3 text-sm text-red-300">{conn?.error || "שגיאת חיבור"}</p>
              )}
              {conn?.ageMin !== null && conn?.ageMin > 30 && (
                <p className="mt-3 rounded-lg border border-amber-900/60 bg-amber-950/40 px-3 py-2 text-sm text-amber-300">
                  הנתונים בזמן אמת לא מתעדכנים כרגע — סביר שהשוק האמריקאי סגור. המחירים מתעדכנים בשעות המסחר
                  (ב'-ו' 16:30–23:00 שעון ישראל).
                </p>
              )}
            </Card>

            <Card icon={Clock} title="עדכניות נתונים לפי טווח זמן (AAPL · MSFT · NVDA)">
              <div className="space-y-3">
                {status.timeframes.map((tfRow) => (
                  <div key={tfRow.tf} className="rounded-xl border border-slate-800 bg-slate-900 p-3">
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm font-semibold text-slate-200">{tfRow.label}</span>
                      <StatusBadge
                        ok={tfRow.samples.some((s) => s.bars > 0 && (s.ageMin === null || s.ageMin < 1440))}
                        okText="מעודכן"
                        failText="לא מעודכן"
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {tfRow.samples.map((s) => (
                        <div key={s.symbol} className="rounded-lg bg-slate-800/60 px-2 py-1.5">
                          <div className="font-semibold text-slate-300">{s.symbol}</div>
                          <div className="text-slate-500">{s.bars} נרות</div>
                          <div className="text-slate-500">
                            {s.lastIso ? new Date(s.lastIso).toLocaleString("he-IL") : "אין נתונים"}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card icon={Database} title="זמינות נתונים לכל אלגוריתם (נרות יומיים · AAPL)">
              <div className="space-y-2">
                {status.algos.map((a) => (
                  <div key={a.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900 px-3 py-2">
                    <span className="text-sm text-slate-200">{a.label}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-500">
                        {a.available} / {a.needed} נרות
                      </span>
                      <StatusBadge ok={a.ok} okText="מספיק" failText="חסר" />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <p className="text-center text-xs text-slate-500">
              נבדק ב־{new Date(status.checkedAt).toLocaleTimeString("he-IL")} · מתרענן אוטומטית כל דקה
            </p>
          </>
        )}
      </div>
    </div>
  );
}
