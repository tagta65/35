import TableShell, { Cell, fmt, NoDataRow } from "./TableShell.jsx";

const HEADERS = ["SYM", "PRICE", "RSI", "VIX", "SQZ", "MOM", "SIG"];

function momCell(status) {
  if (status === 1) return { text: "BULL", cls: "rounded-md bg-[#00E676] font-bold text-slate-950" };
  if (status === 2) return { text: "WEAK", cls: "rounded-md bg-[#00897B] text-white" };
  if (status === 3) return { text: "BEAR", cls: "rounded-md bg-[#FF5252] text-white" };
  return { text: "REV", cls: "rounded-md bg-[#E040FB] text-slate-950" };
}

export default function VixFixTable({ results, zoom }) {
  return (
    <TableShell columns={HEADERS} zoom={zoom}>
      {results.map(({ symbol, data }) => {
        if (!data) return <NoDataRow key={symbol} symbol={symbol} cols={7} />;
        const mom = momCell(data.momStatus);
        const rsiCls = data.rsi >= 70
          ? "text-red-400"
          : data.rsi <= 30 ? "text-emerald-400" : "text-slate-200";
        return (
          <tr key={symbol}>
            <Cell className="rounded-md bg-slate-800/60 font-semibold text-slate-100">{symbol}</Cell>
            <Cell className="rounded-md bg-slate-900/60 text-slate-200">{fmt(data.price)}</Cell>
            <Cell className={`rounded-md bg-slate-900/60 ${rsiCls}`}>{fmt(data.rsi, 1)}</Cell>
            <Cell className={data.vixAlert
              ? "rounded-md bg-[#00E676] font-bold text-slate-950"
              : "rounded-md bg-slate-900/60 text-slate-600"}>
              {data.vixAlert ? "FEAR" : "•"}
            </Cell>
            <Cell className={data.squeeze
              ? "rounded-md bg-[#FF9800] font-bold text-slate-950"
              : "rounded-md bg-slate-900/60 text-slate-600"}>
              {data.squeeze ? "SQZ" : "•"}
            </Cell>
            <Cell className={mom.cls}>{mom.text}</Cell>
            <Cell className={data.buySignal
              ? "rounded-md bg-[#00E676] font-bold text-slate-950"
              : "rounded-md bg-slate-900/60 text-slate-600"}>
              {data.buySignal ? "BUY" : "-"}
            </Cell>
          </tr>
        );
      })}
    </TableShell>
  );
}