import TableShell, { Cell, fmt, NoDataRow } from "./TableShell.jsx";

const HEADERS = ["Symbol", "Price", "Direction", "Score", "Confidence", "Forecast", "Signal"];

const signalClass = {
  BUY: "rounded-md bg-[#00E676] font-bold text-slate-950",
  "LONG BIAS": "rounded-md bg-[#089981] font-bold text-white",
  SELL: "rounded-md bg-[#F23645] font-bold text-white",
  "SHORT BIAS": "rounded-md bg-[#C62828] font-bold text-white",
  WAIT: "rounded-md bg-slate-800 text-slate-400",
};

function scoreClass(score) {
  if (score >= 65) return "rounded-md bg-[#089981]/50 font-bold text-emerald-200";
  if (score <= 35) return "rounded-md bg-[#F23645]/50 font-bold text-red-200";
  return "rounded-md bg-slate-900/60 text-amber-300";
}

function confidenceClass(confidence) {
  if (confidence >= 70) return "rounded-md bg-[#00E676]/70 font-bold text-slate-950";
  if (confidence >= 55) return "rounded-md bg-amber-400/70 font-semibold text-slate-950";
  return "rounded-md bg-slate-900/60 text-slate-300";
}

export default function MrktEdgeTable({ results, zoom }) {
  return (
    <TableShell columns={HEADERS} zoom={zoom}>
      {results.map(({ symbol, data }) => {
        if (!data) return <NoDataRow key={symbol} symbol={symbol} cols={7} />;
        return (
          <tr key={symbol}>
            <Cell className="rounded-md bg-slate-800/60 font-semibold text-slate-100">{symbol}</Cell>
            <Cell className={`rounded-md font-semibold ${data.price >= data.prevClose ? "bg-[#00695C] text-white" : "bg-[#C62828] text-white"}`}>
              {fmt(data.price)}
            </Cell>
            <Cell className={`rounded-md font-semibold ${data.direction === "UP" ? "bg-[#089981]/40 text-emerald-200" : data.direction === "DOWN" ? "bg-[#F23645]/40 text-red-200" : "bg-slate-900/60 text-amber-300"}`}>
              {data.direction}
            </Cell>
            <Cell className={scoreClass(data.score)}>{fmt(data.score, 0)}</Cell>
            <Cell className={confidenceClass(data.confidence)}>{fmt(data.confidence, 0)}%</Cell>
            <Cell className="rounded-md bg-slate-900/60 text-slate-200">{fmt(data.forecast)}</Cell>
            <Cell className={signalClass[data.signal] || signalClass.WAIT}>{data.signal}</Cell>
          </tr>
        );
      })}
    </TableShell>
  );
}
