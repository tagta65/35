import db from "@/api/localDb";

import React, { useState, useEffect } from "react";
import { KeyRound, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TickerManager from "@/components/scanner/TickerManager";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";

export default function KeySettingsDialog({ open, onOpenChange, onSaved }) {
  const [apiKey, setApiKey] = useState("");
  const [secretKey, setSecretKey] = useState("");
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState(null);

  useEffect(() => {
    if (!open) return;
    setStatus(null);
    db.entities.AlpacaKeys.list("-updated_date", 1)
      .then((recs) => {
        if (recs.length) {
          setApiKey(recs[0].apiKey || "");
          setSecretKey(recs[0].secretKey || "");
        } else {
          setApiKey("");
          setSecretKey("");
        }
      })
      .catch(() => {});
  }, [open]);

  const handleSave = async () => {
    if (!apiKey.trim() || !secretKey.trim()) {
      setStatus({ ok: false, msg: "נא למלא את שני המפתחות" });
      return;
    }
    setSaving(true);
    setStatus(null);
    try {
      const recs = await db.entities.AlpacaKeys.list("-updated_date", 1);
      if (recs.length) {
        await db.entities.AlpacaKeys.update(recs[0].id, {
          apiKey: apiKey.trim(),
          secretKey: secretKey.trim(),
        });
      } else {
        await db.entities.AlpacaKeys.create({
          apiKey: apiKey.trim(),
          secretKey: secretKey.trim(),
        });
      }
      setStatus({ ok: true, msg: "המפתחות נשמרו — הסורק ישתמש בהם מיד" });
      if (onSaved) onSaved();
    } catch (e) {
      setStatus({ ok: false, msg: e?.message || "השמירה נכשלה" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir="rtl" className="border-slate-800 bg-slate-900 text-slate-100 sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="h-5 w-5 text-emerald-400" />
            הגדרות סורק
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            נהל כאן את מפתחות הבורסה ואת רשימות המניות.
          </DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="keys" className="pt-1">
          <TabsList className="grid w-full grid-cols-2 bg-slate-950">
            <TabsTrigger value="keys">מפתחות בורסה</TabsTrigger>
            <TabsTrigger value="tickers">ניהול מניות</TabsTrigger>
          </TabsList>
          <TabsContent value="keys" className="space-y-4 pt-2">
          <div className="space-y-2">
            <Label htmlFor="alpaca-key">API Key</Label>
            <Input
              id="alpaca-key"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="PK..."
              className="border-slate-700 bg-slate-950"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="alpaca-secret">Secret Key</Label>
            <Input
              id="alpaca-secret"
              type="password"
              value={secretKey}
              onChange={(e) => setSecretKey(e.target.value)}
              className="border-slate-700 bg-slate-950"
            />
          </div>
          {status && (
            <p className={`text-sm ${status.ok ? "text-emerald-400" : "text-red-400"}`}>
              {status.msg}
            </p>
          )}
          <Button
            onClick={handleSave}
            disabled={saving}
            className="w-full gap-2 bg-emerald-500 text-slate-950 hover:bg-emerald-400"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            שמור מפתחות
          </Button>
          </TabsContent>
          <TabsContent value="tickers" className="pt-2">
            <TickerManager onSaved={onSaved} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}