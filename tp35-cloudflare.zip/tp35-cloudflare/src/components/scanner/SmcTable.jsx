import TableShell, { Cell, fmt, NoDataRow } from "./TableShell.jsx";

const HEADERS = ["SYM", "PRICE", "ENTRY", "SL", "EXIT (% LEFT)", "TARGET"];

function targetCell(d) {
  if (!d.above200) return { cls: "rounded-md bg-[#880E4F] text-white" };
  if (d.upside > 50) return { cls: "rounded-md bg-purple-600 font-semibold text-white" };
  if (d.upside >= 15) return { cls: "rounded-md bg-[#00E676] font-bold text-slate-950" };
  return { cls: "rounded-md bg-[#00695C] text-white" };
}

export default function SmcTable({ results, zoom }) {
  return (
    <TableShell columns={HEADERS} zoom={zoom}>
      {results.map(({ symbol, data }) => {
        if (!data) return <NoDataRow key={symbol} symbol={symbol} cols={6} />;
        const priceCls = data.chg >= 0
          ? "rounded-md bg-[#00695C] font-semibold text-white"
          : "rounded-md bg-[#C62828] font-semibold text-white";
        const entryCls = data.pctToEntry <= 2
          ? "rounded-md bg-[#00897B] text-white"
          : "rounded-md bg-slate-800 text-slate-200";
        const exitCls = data.pctToExit <= 2
          ? "rounded-md bg-[#C62828] text-white"
          : data.pctToExit <= 5
            ? "rounded-md bg-[#FFB300] text-slate-950"
            : "rounded-md bg-slate-800 text-slate-200";
        return (
          <tr key={symbol}>
            <Cell className="rounded-md bg-slate-800/60 font-semibold text-slate-100">{symbol}</Cell>
            <Cell className={priceCls}>{fmt(data.price)}</Cell>
            <Cell className={entryCls}>{fmt(data.idealIn)}</Cell>
            <Cell className="rounded-md bg-slate-800 text-slate-200">{fmt(data.stopLoss)}</Cell>
            <Cell className={exitCls}>
              {fmt(data.exitShort)} ({fmt(data.pctToExit, 1)}%)
            </Cell>
            <Cell className={targetCell(data).cls}>{fmt(data.target)}</Cell>
          </tr>
        );
      })}
    </TableShell>
  );
}