import TableShell, { Cell, fmt, NoDataRow } from "./TableShell.jsx";

const HEADERS = ["Symbol", "Price", "Floor", "Bounce", "Signal", "Action"];

const SIGNAL_TEXT = {
  3: "BOS ↑ HV", 1: "BOS ↑", 4: "RAID LOW", 2: "TOUCH LOW",
  "-4": "RAID HIGH", "-3": "BOS ↓ HV", "-2": "RAID HIGH", "-1": "BOS ↓", 0: "CLEAR",
};

function floorCell(d) {
  if (d.touch) return { text: "TOUCH", cls: "rounded-md bg-[#089981] font-bold text-white" };
  if (d.broken) return { text: "BROKEN", cls: "rounded-md bg-[#f23645] font-bold text-white" };
  if (d.zonePct === null || d.zonePct === undefined) {
    return { text: "N/A", cls: "rounded-md bg-slate-800 text-slate-500" };
  }
  if (d.zonePct > 0) {
    return { text: `-${fmt(d.zonePct, 2)}%`, cls: "rounded-md bg-slate-800 text-slate-300" };
  }
  return { text: "READY", cls: "rounded-md bg-slate-800 text-slate-300" };
}

// V3 colors: raid high = orange warning, BOS down = red, positive = green
function signalCell(d) {
  const text = SIGNAL_TEXT[d.signal] || "CLEAR";
  if (d.signal > 0) return { text, cls: "rounded-md bg-[#089981] font-bold text-white" };
  if (d.signal === -2 || d.signal === -4) return { text, cls: "rounded-md bg-[#f57c00] font-bold text-white" };
  if (d.signal < 0) return { text, cls: "rounded-md bg-[#f23645] font-bold text-white" };
  return { text, cls: "rounded-md bg-slate-800 text-slate-500" };
}

function actionCell(d) {
  if (d.action === "BUY LONG") return { cls: "rounded-md bg-[#089981] font-bold text-white" };
  if (d.action === "AVOID") return { cls: "rounded-md bg-[#f23645] font-bold text-white" };
  if (d.action === "WATCH") return { cls: "rounded-md bg-[#f57c00] font-bold text-white" };
  return { cls: "rounded-md bg-slate-800 text-slate-400" };
}

export default function OrderFlowTable({ results, zoom }) {
  return (
    <TableShell columns={HEADERS} zoom={zoom}>
      {results.map(({ symbol, data }) => {
        if (!data) return <NoDataRow key={symbol} symbol={symbol} cols={6} />;
        const floor = floorCell(data);
        const sig = signalCell(data);
        const act = actionCell(data);
        return (
          <tr key={symbol}>
            <Cell className="rounded-md bg-slate-800 font-semibold text-slate-100">{symbol}</Cell>
            <Cell className="rounded-md bg-slate-800 font-semibold text-[#f0b90b]">
              {fmt(data.price)}
            </Cell>
            <Cell className={floor.cls}>{floor.text}</Cell>
            <Cell className="rounded-md bg-slate-800">
              {data.bouncePct === null || data.bouncePct === undefined ? (
                <span className="text-slate-500">N/A</span>
              ) : (
                <span className="text-[#00e676] font-semibold">+{fmt(data.bouncePct, 2)}%</span>
              )}
            </Cell>
            <Cell className={sig.cls}>{sig.text}</Cell>
            <Cell className={act.cls}>{data.action || "NO TRADE"}</Cell>
          </tr>
        );
      })}
    </TableShell>
  );
}