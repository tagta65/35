import { Minus, Plus, RotateCcw } from "lucide-react";

export default function ZoomControls({ zoom, onZoomChange }) {
  const change = (delta) => {
    const next = zoom + delta;
    if (next >= 50 && next <= 200) onZoomChange(next);
  };

  return (
    <div
      dir="rtl"
      className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/60 px-3 py-2"
    >
      <button
        onClick={() => onZoomChange(50)}
        className="rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 active:bg-slate-800"
        title="הצג את כל הטבלה"
      >
        הצג הכל
      </button>
      <button
        onClick={() => change(-10)}
        className="rounded-lg border border-slate-800 bg-slate-900 p-1.5 text-slate-300 active:bg-slate-800"
        title="הקטן"
      >
        <Minus className="h-4 w-4" />
      </button>
      <input
        type="range"
        min="50"
        max="200"
        step="10"
        value={zoom}
        onChange={(e) => onZoomChange(Number(e.target.value))}
        className="h-1.5 w-36 flex-1 accent-emerald-500 sm:max-w-44"
      />
      <button
        onClick={() => change(10)}
        className="rounded-lg border border-slate-800 bg-slate-900 p-1.5 text-slate-300 active:bg-slate-800"
        title="הגדל"
      >
        <Plus className="h-4 w-4" />
      </button>
      <span className="w-11 text-center text-xs font-semibold text-slate-400">
        {zoom}%
      </span>
      {zoom !== 100 && (
        <button
          onClick={() => onZoomChange(100)}
          className="rounded-lg p-1.5 text-slate-500 active:bg-slate-800"
          title="איפוס"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}