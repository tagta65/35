import TableShell, { Cell, fmt, NoDataRow } from "./TableShell.jsx";

const HEADERS = ["Stock", "4H Flow", "Daily", "Volume", "Trend", "Score", "Signal"];

// f_flowColor
function flowCls(v) {
  if (v > 10) return "text-[#00E676]";
  if (v > 0) return "text-[#089981]";
  if (v < -10) return "text-[#F23645]";
  return "text-[#f57c00]";
}

// f_scoreColor
function scoreCls(v) {
  if (v >= 75) return "text-[#00E676]";
  if (v >= 60) return "text-[#089981]";
  if (v <= 30) return "text-[#F23645]";
  return "text-[#f57c00]";
}

// f_signalColor (as cell backgrounds)
const SIGNAL_CLS = {
  "STRONG BUY": "bg-[#00E676] text-slate-950",
  "BUY PULLBACK": "bg-[#00BCD4] text-slate-950",
  "EARLY BUY": "bg-[#089981] text-white",
  "BUY WATCH": "bg-[#FFEB3B] text-slate-950",
  "STRONG SELL": "bg-[#F23645] text-white",
  "SELL WATCH": "bg-[#f57c00] text-white",
  NEUTRAL: "bg-slate-800 text-slate-400",
};

export default function MtfFlowTable({ results, zoom }) {
  return (
    <TableShell columns={HEADERS} zoom={zoom}>
      {results.map(({ symbol, data }) => {
        if (!data) return <NoDataRow key={symbol} symbol={symbol} cols={7} />;
        return (
          <tr key={symbol}>
            <Cell className="rounded-md bg-slate-800/60 font-semibold text-slate-100">{symbol}</Cell>
            <Cell className={`rounded-md bg-slate-900/60 font-semibold ${flowCls(data.flowL)}`}>
              {fmt(data.flowL, 1)}%
            </Cell>
            <Cell className={`rounded-md bg-slate-900/60 font-semibold ${flowCls(data.flowH)}`}>
              {fmt(data.flowH, 1)}%
            </Cell>
            <Cell className={`rounded-md bg-slate-900/60 font-semibold ${data.volume === "NORMAL" ? "text-slate-500" : "text-[#00E676]"}`}>
              {data.volume}
            </Cell>
            <Cell className={`rounded-md bg-slate-900/60 font-semibold ${data.trend === "UP" ? "text-[#00E676]" : data.trend === "DOWN" ? "text-[#F23645]" : "text-[#f57c00]"}`}>
              {data.trend}
            </Cell>
            <Cell className={`rounded-md bg-slate-900/60 font-bold ${scoreCls(data.score)}`}>
              {fmt(data.score, 0)}
            </Cell>
            <Cell className={`rounded-md text-center text-xs font-bold ${SIGNAL_CLS[data.signal] || SIGNAL_CLS.NEUTRAL}`}>
              {data.signal}
            </Cell>
          </tr>
        );
      })}
    </TableShell>
  );
}