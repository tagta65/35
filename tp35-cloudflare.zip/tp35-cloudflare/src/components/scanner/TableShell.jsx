export function Cell({ className, children }) {
  return (
    <td className={`whitespace-nowrap px-1.5 py-0.5 text-center ${className || ""}`}>
      {children}
    </td>
  );
}

export function fmt(value, digits = 2) {
  if (value === null || value === undefined || Number.isNaN(value)) return "-";
  return Number(value).toFixed(digits);
}

export function NoDataRow({ symbol, cols }) {
  return (
    <tr>
      <Cell className="rounded-md bg-slate-800/60 font-semibold text-slate-200">{symbol}</Cell>
      <Cell className="rounded-md bg-slate-900/60 text-slate-500" >אין נתונים</Cell>
      {Array.from({ length: cols - 2 }).map((_, i) => (
        <Cell key={i} className="rounded-md bg-slate-900/60 text-slate-700">-</Cell>
      ))}
    </tr>
  );
}

export default function TableShell({ columns, children, zoom = 100 }) {
  return (
    <div
      dir="ltr"
      className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/50 p-1.5 sm:p-2"
      style={{ zoom: zoom / 100 }}
    >
      <table className="w-max border-separate border-spacing-y-0.5 text-xs sm:text-sm">
        <thead>
          <tr>
            {columns.map((col) => (
              <th
                key={col}
                className="whitespace-nowrap px-1.5 py-1 text-center text-[11px] font-semibold uppercase tracking-wider text-slate-500"
              >
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}