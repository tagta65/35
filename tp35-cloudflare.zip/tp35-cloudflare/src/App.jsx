import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import DisplaySettings from './pages/DisplaySettings';
import ScannerAlerts from './pages/ScannerAlerts';
import SystemStatus from './pages/SystemStatus';

function App() {
  return (
    <QueryClientProvider client={queryClientInstance}>
      <Router>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/display-settings" element={<DisplaySettings />} />
          <Route path="/scanner-alerts" element={<ScannerAlerts />} />
          <Route path="/system-status" element={<SystemStatus />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </Router>
      <Toaster />
    </QueryClientProvider>
  )
}

export default App
