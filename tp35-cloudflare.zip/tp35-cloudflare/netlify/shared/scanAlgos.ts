// The four scanner algorithms, ported from the TradingView scripts
import {
  smaAt, stdevAt, emaArr, rsiArr, atrArr, winMax, winMin, linregAtWindow, sumRange,
} from "./market.ts";

export const BARS_NEEDED = { p402: 80, vixfix: 110, analog: 300, smc: 300, orderflow: 80, mtfflow: 80, mrktedge: 320 };

// ---------- Algorithm 1: Protocol 402 + Supply Squeeze ----------
export function scanP402(bars) {
  if (bars.length < 30) return null;
  const closes = bars.map((b) => b.c);
  const opens = bars.map((b) => b.o);
  const highs = bars.map((b) => b.h);
  const lows = bars.map((b) => b.l);
  const vols = bars.map((b) => b.v);
  const n = closes.length - 1;
  const c = closes[n];

  const volSma = smaAt(vols, n, 20);
  let tightDays = 0;
  let upVol = 0;
  let downVol = 0;
  for (let i = n - 9; i <= n; i++) {
    if (closes[i] && ((highs[i] - lows[i]) / closes[i]) * 100 <= 2.0) tightDays++;
    if (closes[i] >= opens[i]) upVol += vols[i];
    else downVol += vols[i];
  }
  const avgVolWin = sumRange(vols, n - 9, n) / 10;
  const isVolHigh = volSma ? avgVolWin >= volSma * 1.2 : false;
  const isSupplyDry = upVol > 0 ? downVol / upVol <= 0.6 : false;
  const squeezeScore = tightDays * 10;
  const squeezeReady = tightDays >= 6 && isVolHigh && isSupplyDry;

  const e8 = emaArr(closes, 8)[n];
  const e21 = emaArr(closes, 21)[n];
  const swLow = winMin(lows, n, 14);
  const idealEntry = Math.min(e21, swLow);
  const distPct = c ? ((c - idealEntry) / c) * 100 : 0;
  const prevC = closes[n - 1];
  const dayChange = prevC ? ((c - prevC) / prevC) * 100 : 0;
  const rvol = volSma ? vols[n] / volSma : null;
  const riding = c > e8 && c > e21 && rvol !== null && rvol >= 1.1 && dayChange > 0;
  const stretched = distPct >= 8.0;

  return { price: c, idealEntry, distPct, dayChange, rvol, squeezeReady, squeezeScore, riding, stretched };
}

// ---------- Algorithm 2: Vix Fix + Squeeze Momentum + RSI ----------
export function scanVixFix(bars) {
  if (bars.length < 75) return null;
  const closes = bars.map((b) => b.c);
  const highs = bars.map((b) => b.h);
  const lows = bars.map((b) => b.l);
  const n = closes.length - 1;

  const wvfArr = closes.map((c, i) => {
    if (i < 21) return null;
    const hi = winMax(closes, i, 22);
    return ((hi - lows[i]) / hi) * 100;
  });

  const alertAt = (i) => {
    if (i < 70) return false;
    const mid = smaAt(wvfArr, i, 20);
    const dev = stdevAt(wvfArr, i, 20);
    const upper = mid + 2 * dev;
    const rangeHigh = winMax(wvfArr, i, 50) * 0.85;
    return wvfArr[i] >= upper || wvfArr[i] >= rangeHigh;
  };
  const recentAlert = alertAt(n) || alertAt(n - 1) || alertAt(n - 2);

  const basis = smaAt(closes, n, 20);
  const dev = 2 * stdevAt(closes, n, 20);
  const upperBB = basis + dev;
  const lowerBB = basis - dev;

  const tr = closes.map((c, i) => i === 0
    ? highs[0] - lows[0]
    : Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1])));
  const rangeKC = smaAt(tr, n, 20);
  const upperKC = basis + rangeKC * 1.5;
  const lowerKC = basis - rangeKC * 1.5;
  const squeezeOn = lowerBB > lowerKC && upperBB < upperKC;

  const sArr = new Array(n + 1).fill(null);
  for (let i = 39; i <= n; i++) {
    const hh = winMax(highs, i, 20);
    const ll = winMin(lows, i, 20);
    const sm = smaAt(closes, i, 20);
    sArr[i] = closes[i] - (((hh + ll) / 2 + sm) / 2);
  }
  const val = linregAtWindow(sArr, 20, n);
  const valPrev = linregAtWindow(sArr, 20, n - 1);
  const momStatus = val >= 0 ? (val > valPrev ? 1 : 2) : (val < valPrev ? 3 : 4);
  const buySignal = recentAlert && (momStatus === 4 || (val > 0 && valPrev <= 0));

  const rsi = rsiArr(closes, 14)[n];
  return { price: closes[n], rsi, vixAlert: alertAt(n), squeeze: squeezeOn, momStatus, buySignal };
}

// ---------- Algorithm 3: MRKT EDGE 402 v2 — Historical Analog Engine ----------
const ANALOG_LOOKBACK = 250;  // Historical Search Bars
const ANALOG_HORIZON = 5;     // Forecast Horizon (Bars)
const ANALOG_TOLERANCE = 0.55; // Similarity Tolerance
const ROC_LEN = 10;

export function scanAnalog(bars) {
  if (bars.length < 110) return null;
  const closes = bars.map((b) => b.c);
  const highs = bars.map((b) => b.h);
  const lows = bars.map((b) => b.l);
  const n = closes.length - 1;
  const c = closes[n];

  const rsiFull = rsiArr(closes, 14);
  const atrFull = atrArr(highs, lows, closes, 14);
  const ema20Full = emaArr(closes, 20);

  const rsi = rsiFull[n];
  const atr = atrFull[n];
  if (atr === null || rsi === null) return null;
  const atrPct = c ? (atr / c) * 100 : 0;
  const emaFast = ema20Full[n];

  // ta.roc(close, 10)
  const rocAt = (idx) => {
    const prev = closes[idx - ROC_LEN];
    return prev ? ((closes[idx] / prev) - 1) * 100 : null;
  };
  const roc = rocAt(n);
  if (roc === null) return null;

  let analogReturnSum = 0;
  let analogCount = 0;
  let analogBullCount = 0;
  let analogBearCount = 0;
  const currentTrend = c > emaFast ? 1 : -1;

  // Search as much history as the fetched bars allow (up to ANALOG_LOOKBACK)
  const maxK = Math.min(ANALOG_LOOKBACK, n - ROC_LEN - 2);
  for (let k = ANALOG_HORIZON + 2; k <= maxK; k++) {
    const j = n - k; // array index of Pine close[k]
    if (j - ROC_LEN < 0) continue;
    const histC = closes[j];
    const hRsi = rsiFull[j];
    const hRoc = rocAt(j);
    const hAtr = atrFull[j];
    const hEmaFast = ema20Full[j];
    if (histC == null || hRsi == null || hRoc == null || hAtr == null || hEmaFast == null) continue;

    const hAtrPct = (hAtr / histC) * 100;
    const hTrend = histC > hEmaFast ? 1 : -1;

    const distance =
      Math.abs(rsi - hRsi) / 100 +
      Math.abs(roc - hRoc) / 10 +
      Math.abs(atrPct - hAtrPct) / 5 +
      (hTrend === currentTrend ? 0 : 0.5);

    if (distance <= ANALOG_TOLERANCE) {
      const futureC = closes[j + ANALOG_HORIZON]; // Pine close[k - horizon]
      const hReturn = ((futureC / histC) - 1) * 100;
      analogReturnSum += hReturn;
      analogCount += 1;
      if (hReturn > 0) analogBullCount += 1;
      if (hReturn < 0) analogBearCount += 1;
    }
  }

  const analogAvgReturn = analogCount > 0 ? analogReturnSum / analogCount : 0;
  const analogUpPct = analogCount > 0 ? (analogBullCount / analogCount) * 100 : 50;

  // MTF score: SMA10/20/50/200 + RSI, +/-4 each
  const sma10 = smaAt(closes, n, 10);
  const sma20 = smaAt(closes, n, 20);
  const sma50 = smaAt(closes, n, 50);
  const sma200 = smaAt(closes, n, 200);
  let mtfScore = 0;
  let mtfValid = true;
  [sma10, sma20, sma50, sma200].forEach((m) => {
    if (m === null) mtfValid = false;
    else mtfScore += c > m ? 4 : -4;
  });
  if (rsi === null) mtfValid = false;
  else mtfScore += rsi > 50 ? 4 : -4;

  const fund = sma200 ? ((c - sma200) / sma200) * 100 : 0;

  return {
    price: c,
    rsi,
    fund,
    mtfScore: mtfValid ? mtfScore : null,
    analogPct: analogUpPct,
    analogAvgReturn,
    matchedCount: analogCount,
  };
}

// ---------- Algorithm 4: SMC entries / stop / exit / target ----------
export function scanSmc(bars) {
  if (bars.length < 30) return null;
  const closes = bars.map((b) => b.c);
  const highs = bars.map((b) => b.h);
  const lows = bars.map((b) => b.l);
  const n = closes.length - 1;
  const c = closes[n];

  const chg = c - closes[n - 1];
  const idealIn = winMin(lows, n, 20);
  const atr = atrArr(highs, lows, closes, 14)[n];
  if (atr === null) return null;
  const stopLoss = idealIn - 1.5 * atr;
  const exitShort = winMax(highs, n, 20);
  const pctToExit = c ? ((exitShort - c) / c) * 100 : 0;
  const pctToEntry = c ? ((c - idealIn) / c) * 100 : 0;
  const sma200 = smaAt(closes, n, 200);
  const high52 = winMax(highs, n, Math.min(252, n + 1));
  const above200 = sma200 ? c > sma200 : false;
  const target = Math.max(high52 * 1.12, c + 4 * atr);
  const upside = c ? ((target - c) / c) * 100 : 0;

  return {
    price: c, chg, idealIn, stopLoss, exitShort, pctToExit, pctToEntry, target, upside, above200,
  };
}

// ---------- Algorithm 5: Multi-Ticker Order Flow Dashboard V3 ----------
// Faithful port of the TradingView script: pivot structure, buyers/bear zone,
// BOS, liquidity raid, signal memory, high-volume confirmation and ACTION.
export const ORDERFLOW_SIGNALS = {
  3: "BOS ↑ HV", 1: "BOS ↑", 4: "RAID LOW", 2: "TOUCH LOW",
  "-4": "RAID HIGH", "-3": "BOS ↓ HV", "-2": "RAID HIGH", "-1": "BOS ↓", 0: "CLEAR",
};

export function scanOrderFlow(bars) {
  const PIVOT = 3, LOOKBACK = 10, VLEN = 20, VFACT = 1.20;
  if (bars.length < VLEN + PIVOT + 1) return null;

  // --- Pine var state ---
  let lastHigh = null;   // var float lastHigh
  let lastLow = null;    // var float lastLow
  let bullLow = null, bullHigh = null;   // buyers zone (from pivot low)
  let bearHigh = null, bearLow = null;   // bear zone (from pivot high)
  let lastSignal = 0, lastSignalBar = null;
  let signal = 0, highVolume = false;

  for (let i = 0; i < bars.length; i++) {
    const b = bars[i];

    // ta.pivothigh / ta.pivotlow - confirmed PIVOT bars after the center bar
    const p = i - PIVOT;
    if (p >= PIVOT) {
      const center = bars[p];
      let ph = true, pl = true;
      for (let k = 1; k <= PIVOT; k++) {
        if (center.h <= bars[p - k].h || center.h <= bars[p + k].h) ph = false;
        if (center.l >= bars[p - k].l || center.l >= bars[p + k].l) pl = false;
      }
      if (ph) { lastHigh = center.h; bearHigh = center.h; bearLow = center.l; }
      if (pl) { lastLow = center.l; bullLow = center.l; bullHigh = center.h; }
    }

    // ta.sma(volume, VLEN) + high volume factor
    let avgVolume = null;
    if (i >= VLEN - 1) {
      let s = 0;
      for (let k = i - VLEN + 1; k <= i; k++) s += bars[k].v;
      avgVolume = s / VLEN;
    }
    highVolume = avgVolume !== null && b.v > avgVolume * VFACT;

    // BUYERS ZONE status
    const touchBuyers = bullHigh !== null && bullLow !== null && b.l <= bullHigh && b.c >= bullLow;
    const belowFloor = bullLow !== null && b.c < bullLow;

    // BOS - ta.crossover / ta.crossunder of close over last pivot
    const prevC = i > 0 ? bars[i - 1].c : null;
    const bosUp = lastHigh !== null && prevC !== null && b.c > lastHigh && prevC <= lastHigh;
    const bosDown = lastLow !== null && prevC !== null && b.c < lastLow && prevC >= lastLow;

    // LIQUIDITY RAID
    const raidHigh = bearHigh !== null && b.h > bearHigh && b.c <= bearHigh;
    const raidLow = bullLow !== null && b.l < bullLow && b.c >= bullLow;

    // SIGNAL MEMORY
    if (bosUp) { lastSignal = 1; lastSignalBar = i; }
    if (bosDown) { lastSignal = -1; lastSignalBar = i; }
    if (raidHigh) { lastSignal = -2; lastSignalBar = i; }
    if (raidLow) { lastSignal = 2; lastSignalBar = i; }

    const signalActive = lastSignalBar !== null && i - lastSignalBar <= LOOKBACK;
    signal = signalActive ? lastSignal : 0;

    // Strong confirmation with high volume
    if (bosUp && highVolume) signal = 3;
    if (bosDown && highVolume) signal = -3;
    if (raidHigh && highVolume) signal = -4;
    if (raidLow && highVolume) signal = 4;
  }

  // --- Last bar values (f_row inputs) ---
  const n = bars.length - 1;
  const c = bars[n].c;
  const lastBar = bars[n];
  const touch = bullHigh !== null && bullLow !== null && lastBar.l <= bullHigh && c >= bullLow;
  const broken = bullLow !== null && c < bullLow;
  const zonePct = bullHigh !== null ? (c < bullHigh ? ((bullHigh - c) / c) * 100 : 0) : null;
  const bouncePct = bearHigh !== null && bearHigh > c ? ((bearHigh - c) / c) * 100 : null;

  // f_action - ACTION column weighting
  let action = "NO TRADE";
  if (!broken && (signal === 1 || signal === 2 || signal === 3 || signal === 4)) action = "BUY LONG";
  else if (broken || signal === -1 || signal === -3) action = "AVOID";
  else if (signal === -2 || signal === -4 || touch) action = "WATCH";

  return { price: c, zonePct, touch, broken, bouncePct, signal, highVolume, action };
}

// ---------- Algorithm 6: MTF Flow Scanner PRO (4H + Daily) ----------
// Faithful port of the TradingView script: order-flow delta engine computed on
// a lower (4H) and higher (daily) timeframe, combined into a score + signal.

// f_flow() - one timeframe's flow data
export function mtfFlowCalc(bars, flowLen, emaFastLen, emaSlowLen) {
  const n = bars.length - 1;
  if (n < Math.max(flowLen, emaSlowLen)) return null;
  const closes = bars.map((b) => b.c);
  const highs = bars.map((b) => b.h);
  const lows = bars.map((b) => b.l);
  const vols = bars.map((b) => b.v);

  // per-bar order-flow delta
  const deltas = new Array(n + 1).fill(0);
  for (let i = 0; i <= n; i++) {
    const rng = Math.max(highs[i] - lows[i], 0.01); // syminfo.mintick fallback
    const buyPressure = (vols[i] * (closes[i] - lows[i])) / rng;
    const sellPressure = (vols[i] * (highs[i] - closes[i])) / rng;
    deltas[i] = ((buyPressure - sellPressure) / Math.max(vols[i], 1)) * 100;
  }

  const deltaMA = smaAt(deltas, n, flowLen);
  const volMA = smaAt(vols, n, flowLen);
  const e21 = emaArr(closes, emaFastLen)[n];
  const e50 = emaArr(closes, emaSlowLen)[n];
  if (deltaMA === null || volMA === null || e21 === null || e50 === null) return null;

  return {
    delta: deltas[n],
    deltaMA,
    volRatio: vols[n] / Math.max(volMA, 1),
    trend: closes[n] > e21 && e21 > e50 ? 1 : closes[n] < e21 && e21 < e50 ? -1 : 0,
  };
}

export function scanMtfFlow(barsL, barsH) {
  const FLEN = 20;
  const L = mtfFlowCalc(barsL, FLEN, 21, 50);
  const H = mtfFlowCalc(barsH, FLEN, 21, 50);
  if (!L || !H) return null;

  // f_score engine
  let score = 50;
  if (L.delta > 10) score += 10;
  else if (L.delta > 0) score += 5;
  else if (L.delta < -10) score -= 10;
  else if (L.delta < 0) score -= 5;
  if (H.delta > 10) score += 15;
  else if (H.delta > 0) score += 7;
  else if (H.delta < -10) score -= 15;
  else if (H.delta < 0) score -= 7;
  if (L.deltaMA > 0 && H.deltaMA > 0) score += 8;
  if (L.deltaMA < 0 && H.deltaMA < 0) score -= 8;
  if (L.volRatio > 1.3) score += 5;
  if (H.volRatio > 1.3) score += 5;
  if (L.trend === 1) score += 5;
  if (H.trend === 1) score += 5;
  if (L.trend === -1) score -= 5;
  if (H.trend === -1) score -= 5;
  score = Math.max(0, Math.min(100, score));

  // f_signal engine
  const strongBuy = L.delta > 15 && H.delta > 10 && L.deltaMA > 0 && H.deltaMA > 0;
  const pullbackBuy = L.delta > 20 && H.delta < 5 && L.deltaMA > 0 && H.trend === 1;
  const earlyBuy = L.delta > 10 && L.deltaMA > 0 && L.volRatio > 1.2;
  const strongSell = L.delta < -15 && H.delta < -10 && L.deltaMA < 0 && H.deltaMA < 0;
  let signal = "NEUTRAL";
  if (strongBuy) signal = "STRONG BUY";
  else if (pullbackBuy) signal = "BUY PULLBACK";
  else if (earlyBuy) signal = "EARLY BUY";
  else if (strongSell) signal = "STRONG SELL";
  else if (L.delta > 0 && H.delta > 0) signal = "BUY WATCH";
  else if (L.delta < 0 && H.delta < 0) signal = "SELL WATCH";

  const trend = L.trend === 1 && H.trend === 1 ? "UP" : L.trend === -1 && H.trend === -1 ? "DOWN" : "MIXED";
  const volume = L.volRatio >= 1.5 ? "HIGH" : L.volRatio >= 1.2 ? "GOOD" : "NORMAL";

  return {
    price: barsL[barsL.length - 1].c,
    flowL: L.delta,
    flowH: H.delta,
    volume,
    trend,
    score,
    signal,
  };
}
