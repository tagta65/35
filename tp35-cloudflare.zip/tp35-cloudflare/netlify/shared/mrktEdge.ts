// MRKT EDGE 402 v2 — JavaScript port of the Pine Script v6 indicator.
// Every engine mirrors the original; the last two bars are evaluated so that
// "newBull / newBear" (strong signal that was not strong on the previous bar) works.

const NaNv = NaN;
const fin = (x) => Number.isFinite(x);
const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));

const DEFAULTS = {
  emaFast: 20, emaMid: 50, emaSlow: 200,
  rsiLen: 14, atrLen: 14, rocLen: 10, volLen: 20, breakoutLen: 20,
  useAnalog: true, analogLookback: 250, analogHorizon: 5, analogTol: 0.55,
  useMarket: true, useMTF: true,
  useExternal: false, externalBias: 0, externalWeight: 8,
  target1ATR: 1.0, target2ATR: 2.0, stopATR: 1.0, gannMult: 1.618,
  threshold: 70,
};

// ───────── series helpers (Pine-compatible) ─────────
function ema(src, len) {
  const a = 2 / (len + 1), out = new Array(src.length).fill(NaNv);
  let prev = NaNv;
  for (let i = 0; i < src.length; i++) {
    const v = src[i];
    if (!fin(v)) { out[i] = prev; continue; }
    prev = fin(prev) ? a * v + (1 - a) * prev : v;
    out[i] = prev;
  }
  return out;
}
function rma(src, len) {
  const out = new Array(src.length).fill(NaNv);
  let prev = NaNv;
  for (let i = 0; i < src.length; i++) {
    if (fin(prev)) {
      prev = (src[i] + (len - 1) * prev) / len;
    } else if (i >= len - 1) {
      let s = 0, ok = true;
      for (let j = i - len + 1; j <= i; j++) { if (!fin(src[j])) { ok = false; break; } s += src[j]; }
      prev = ok ? s / len : NaNv;
    }
    out[i] = prev;
  }
  return out;
}
function sma(src, len) {
  const out = new Array(src.length).fill(NaNv);
  for (let i = len - 1; i < src.length; i++) {
    let s = 0, ok = true;
    for (let j = i - len + 1; j <= i; j++) { if (!fin(src[j])) { ok = false; break; } s += src[j]; }
    if (ok) out[i] = s / len;
  }
  return out;
}
function rsiSeries(close, len) {
  const up = new Array(close.length).fill(NaNv), dn = new Array(close.length).fill(NaNv);
  for (let i = 1; i < close.length; i++) {
    const ch = close[i] - close[i - 1];
    up[i] = Math.max(ch, 0); dn[i] = Math.max(-ch, 0);
  }
  const u = rma(up, len), d = rma(dn, len);
  return close.map((_, i) => {
    if (!fin(u[i]) || !fin(d[i])) return NaNv;
    if (d[i] === 0) return 100;
    if (u[i] === 0) return 0;
    return 100 - 100 / (1 + u[i] / d[i]);
  });
}
function atrSeries(h, l, c, len) {
  const tr = h.map((_, i) => i === 0 ? h[i] - l[i] : Math.max(h[i] - l[i], Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1])));
  return rma(tr, len);
}
function rocSeries(c, len) {
  return c.map((v, i) => i >= len && c[i - len] !== 0 ? 100 * (v - c[i - len]) / c[i - len] : NaNv);
}
// previous-window highest/lowest: ta.highest(high, n)[1]
function prevExtreme(src, n, fn) {
  return src.map((_, i) => {
    if (i < n) return NaNv;
    let v = src[i - n];
    for (let j = i - n + 1; j <= i - 1; j++) v = fn(v, src[j]);
    return v;
  });
}

// forward-fill a reference series onto the main bars by date (request.security semantics)
function alignByDate(mainBars, refBars) {
  const out = new Array(mainBars.length).fill(NaNv);
  if (!refBars || !refBars.length) return out;
  let j = -1;
  for (let i = 0; i < mainBars.length; i++) {
    while (j + 1 < refBars.length && refBars[j + 1].date <= mainBars[i].date) j++;
    out[i] = j >= 0 ? refBars[j] : NaNv;
  }
  return out;
}

// 4h bars built from hourly bars (4-hour UTC buckets)
function aggregate4h(hourly) {
  const out = [];
  let cur = null, key = null;
  for (const b of hourly) {
    const k = Math.floor(b.t / (4 * 3600e3));
    if (k !== key) { if (cur) out.push(cur); cur = { ...b }; key = k; }
    else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); cur.c = b.c; cur.v += b.v; cur.date = b.date; }
  }
  if (cur) out.push(cur);
  return out;
}
// state series: +1 / -1 (close > EMA50) with each bar's date
function stateSeries(bars) {
  const c = bars.map((b) => b.c), e = ema(c, 50);
  return bars.map((b, i) => ({ date: b.date, state: c[i] > e[i] ? 1 : -1 }));
}
function stateAtDate(states, dailyBars) {
  const out = new Array(dailyBars.length).fill(NaNv);
  let j = -1;
  for (let i = 0; i < dailyBars.length; i++) {
    while (j + 1 < states.length && states[j + 1].date <= dailyBars[i].date) j++;
    out[i] = j >= 0 ? states[j].state : NaNv;
  }
  return out;
}

// ───────── main analysis ─────────
// bars: daily bars of the symbol. ctx: { spy, qqq, vix, hourly } (arrays of bars or null)
function analyze(bars, ctx = {}, opts = {}) {
  const P = { ...DEFAULTS, ...opts };
  const n = bars.length;
  if (n < 60) throw new Error(`Not enough bars (${n})`);

  const o = bars.map((b) => b.o), h = bars.map((b) => b.h), l = bars.map((b) => b.l),
        c = bars.map((b) => b.c), v = bars.map((b) => b.v);

  const emaF = ema(c, P.emaFast), emaM = ema(c, P.emaMid), emaS = ema(c, P.emaSlow);
  const rsi = rsiSeries(c, P.rsiLen), atr = atrSeries(h, l, c, P.atrLen), roc = rocSeries(c, P.rocLen);
  const volMA = sma(v, P.volLen), sma20 = sma(c, 20);
  const hiPrev = prevExtreme(h, P.breakoutLen, Math.max), loPrev = prevExtreme(l, P.breakoutLen, Math.min);

  // reference markets
  const qqqC = alignByDate(bars, ctx.qqq).map((b) => (b ? b.c : NaNv));
  const spyC = alignByDate(bars, ctx.spy).map((b) => (b ? b.c : NaNv));
  const vixC = alignByDate(bars, ctx.vix).map((b) => (b ? b.c : NaNv));
  const spyE = ema(ctx.spy ? ctx.spy.map((b) => b.c) : [], 50);
  const qqqE = ema(ctx.qqq ? ctx.qqq.map((b) => b.c) : [], 50);
  const spyEma50 = alignByDate(bars, ctx.spy ? ctx.spy.map((b, i) => ({ date: b.date, e: spyE[i] })) : null).map((x) => (x ? x.e : NaNv));
  const qqqEma50 = alignByDate(bars, ctx.qqq ? ctx.qqq.map((b, i) => ({ date: b.date, e: qqqE[i] })) : null).map((x) => (x ? x.e : NaNv));

  // multi-timeframe states: 1H, 4H (from hourly) and 1D
  const dailyState = bars.map((_, i) => (c[i] > emaM[i] ? 1 : -1));
  let mtf1 = dailyState, mtf2 = dailyState, mtfFallback = true;
  if (ctx.hourly && ctx.hourly.length > 60) {
    mtf1 = stateAtDate(stateSeries(ctx.hourly), bars);
    mtf2 = stateAtDate(stateSeries(aggregate4h(ctx.hourly)), bars);
    mtfFallback = false;
  }
  const mtf3 = dailyState;

  function evaluate(i) {
    const cl = c[i];
    // trend
    let trend = 0;
    trend += cl > emaF[i] ? 5 : -5;
    trend += emaF[i] > emaM[i] ? 5 : -5;
    trend += emaM[i] > emaS[i] ? 5 : -5;
    trend += cl > emaS[i] ? 5 : -5;
    trend = clamp(trend, -20, 20);

    // momentum
    let mom = 0;
    mom += rsi[i] > 50 ? 5 : -5;
    mom += rsi[i] > 60 ? 5 : rsi[i] < 40 ? -5 : 0;
    mom += roc[i] > 0 ? 5 : -5;
    mom += i >= 5 && cl > c[i - 5] ? 5 : -5;
    mom = clamp(mom, -20, 20);

    // volume
    const vr = fin(volMA[i]) && volMA[i] !== 0 ? v[i] / volMA[i] : 1;
    let vol = 0;
    vol += vr > 1.2 ? 5 : 0;
    vol += vr > 1.5 ? 5 : 0;
    vol += cl > o[i] && vr > 1 ? 5 : 0;
    vol += cl < o[i] && vr > 1 ? -5 : 0;
    vol = clamp(vol, -15, 15);

    // breakout
    const bullBreakout = cl > hiPrev[i], bearBreakdown = cl < loPrev[i];
    let brk = (bullBreakout ? 15 : 0) + (bearBreakdown ? -15 : 0);
    brk = clamp(brk, -15, 15);

    // relative strength vs QQQ
    let rel = 0, relChange = 0;
    const ratio = (j) => (fin(qqqC[j]) && qqqC[j] !== 0 ? c[j] / qqqC[j] : 0);
    if (i >= 20) {
      const past = ratio(i - 20);
      relChange = past !== 0 ? (ratio(i) / past - 1) * 100 : 0;
    }
    rel += relChange > 0 ? 7 : -7;
    rel += relChange > 2 ? 3 : 0;
    rel += relChange < -2 ? -3 : 0;
    rel = clamp(rel, -10, 10);

    // market regime
    let market = 0;
    if (P.useMarket) {
      market += spyC[i] > spyEma50[i] ? 5 : -5;
      market += qqqC[i] > qqqEma50[i] ? 5 : -5;
      market += vixC[i] < 20 ? 5 : 0;
      market += vixC[i] > 30 ? -5 : 0;
    }
    market = clamp(market, -15, 15);

    // multi-timeframe
    let mtf = 0;
    if (P.useMTF) {
      mtf += mtf1[i] > 0 ? 4 : -4;
      mtf += mtf2[i] > 0 ? 4 : -4;
      mtf += mtf3[i] > 0 ? 4 : -4;
    }
    mtf = clamp(mtf, -12, 12);

    // volatility
    const atrPct = cl !== 0 ? (atr[i] / cl) * 100 : 0;
    let volat = 0;
    volat += atrPct < 2.5 ? 3 : 0;
    volat += atrPct > 5 ? -5 : 0;
    volat = clamp(volat, -5, 5);

    const external = P.useExternal ? P.externalBias * P.externalWeight : 0;

    // historical analog engine
    let aSum = 0, aCount = 0, aBull = 0, aBear = 0;
    const searchStart = P.analogHorizon + 2, searchEnd = P.analogLookback;
    if (P.useAnalog && i > searchEnd + P.analogHorizon) {
      const curTrend = cl > emaF[i] ? 1 : -1;
      for (let k = searchStart; k <= searchEnd; k++) {
        const idx = i - k;
        const hRsi = rsi[idx], hRoc = roc[idx];
        if (!fin(hRsi) || !fin(hRoc) || !fin(atr[idx])) continue;
        const hAtrPct = c[idx] !== 0 ? (atr[idx] / c[idx]) * 100 : 0;
        const hTrend = c[idx] > emaF[idx] ? 1 : -1;
        const dist = Math.abs(rsi[i] - hRsi) / 100 + Math.abs(roc[i] - hRoc) / 10
                   + Math.abs(atrPct - hAtrPct) / 5 + (hTrend === curTrend ? 0 : 0.5);
        const hRet = c[idx] !== 0 ? (c[idx + P.analogHorizon] / c[idx] - 1) * 100 : 0;
        if (dist <= P.analogTol) {
          aSum += hRet; aCount++;
          if (hRet > 0) aBull++;
          if (hRet < 0) aBear++;
        }
      }
    }
    const aAvg = aCount > 0 ? aSum / aCount : 0;
    const aBullP = aCount > 0 ? (aBull / aCount) * 100 : 50;
    const aBearP = aCount > 0 ? (aBear / aCount) * 100 : 50;
    const analog = P.useAnalog && aCount >= 3 ? clamp(aAvg * 5, -15, 15) : 0;

    // gann-style (ported as written: close is never > close + ATR*mult)
    const gUpper = cl + atr[i] * P.gannMult, gLower = cl - atr[i] * P.gannMult;
    let gann = 0;
    gann += cl > sma20[i] ? 4 : -4;
    gann += cl > gUpper ? 4 : 0;
    gann += cl < gLower ? -4 : 0;
    gann = clamp(gann, -8, 8);

    const raw = trend + mom + vol + brk + rel + market + mtf + volat + analog + gann + external;
    const score = clamp(50 + (raw / 130) * 50, 0, 100);
    const direction = score >= 65 ? 'UP' : score <= 35 ? 'DOWN' : 'RANGE';

    // confidence
    const base = 50 + Math.abs(score - 50);
    const aConf = aCount >= 10 ? 8 : aCount >= 5 ? 5 : 0;
    const aAgree = (direction === 'UP' && aBullP >= 60) || (direction === 'DOWN' && aBearP >= 60) ? 7 : 0;
    const mAgree = (direction === 'UP' && mtf > 5) || (direction === 'DOWN' && mtf < -5) ? 5 : 0;
    const confidence = clamp(base + aConf + aAgree + mAgree, 0, 99);

    // forecast
    const atrEM = (atr[i] / cl) * 100;
    const hist = aCount >= 3 ? Math.abs(aAvg) : atrEM;
    const expMove = Math.max(atrEM * 0.6, Math.min(atrEM * 2.5, hist));
    let forecast = cl;
    if (direction === 'UP') forecast = cl * (1 + expMove / 100);
    if (direction === 'DOWN') forecast = cl * (1 - expMove / 100);

    const a = atr[i];
    return {
      direction, score, confidence, forecast,
      target1: direction === 'UP' ? cl + a * P.target1ATR : direction === 'DOWN' ? cl - a * P.target1ATR : null,
      target2: direction === 'UP' ? cl + a * P.target2ATR : direction === 'DOWN' ? cl - a * P.target2ATR : null,
      invalidation: direction === 'UP' ? cl - a * P.stopATR : direction === 'DOWN' ? cl + a * P.stopATR : null,
      strongBull: direction === 'UP' && confidence >= P.threshold,
      strongBear: direction === 'DOWN' && confidence >= P.threshold,
      engines: { trend, momentum: mom, volume: vol, breakout: brk, relative: rel, market, mtf, volatility: volat, analog, gann, external },
      analog: { matches: aCount, avgReturn: aAvg, upProb: aBullP },
      rsi: rsi[i], atr: a,
    };
  }

  const last = n - 1;
  const cur = evaluate(last), prev = evaluate(last - 1);
  const newBull = cur.strongBull && !prev.strongBull;
  const newBear = cur.strongBear && !prev.strongBear;
  const signal = newBull ? 'BUY' : newBear ? 'SELL' : cur.strongBull ? 'LONG BIAS' : cur.strongBear ? 'SHORT BIAS' : 'WAIT';

  return {
    price: c[last], prevClose: c[last - 1], date: bars[last].date,
    signal, ...cur, newBull, newBear, mtfFallback,
  };
}

export { analyze, DEFAULTS };
