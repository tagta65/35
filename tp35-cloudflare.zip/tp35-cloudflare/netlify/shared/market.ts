// Shared market-data utilities for the stock scanner (Alpaca data API)

export const TICKERS = [
  { symbol: "AAPL", name: "Apple" },
  { symbol: "MSFT", name: "Microsoft" },
  { symbol: "NVDA", name: "NVIDIA" },
  { symbol: "AMD", name: "AMD" },
  { symbol: "TSLA", name: "Tesla" },
  { symbol: "AMZN", name: "Amazon" },
  { symbol: "META", name: "Meta" },
  { symbol: "GOOGL", name: "Alphabet" },
  { symbol: "SNDK", name: "SanDisk" },
  { symbol: "COIN", name: "Coinbase" },
  { symbol: "INTC", name: "Intel" },
  { symbol: "QCOM", name: "Qualcomm" },
  { symbol: "PLTR", name: "Palantir" },
  { symbol: "AVGO", name: "Broadcom" },
  { symbol: "MSTR", name: "MicroStrategy" },
  { symbol: "TEAM", name: "Atlassian" },
  { symbol: "TXN", name: "Texas Instruments" },
  { symbol: "AMGN", name: "Amgen" },
  { symbol: "SMCI", name: "SMCI" },
  { symbol: "SPCX", name: "SPCX" },
  { symbol: "CSCO", name: "Cisco" },
  { symbol: "CRWD", name: "CrowdStrike" },
  { symbol: "AMAT", name: "Applied Materials" },
  { symbol: "INTU", name: "Intuit" },
  { symbol: "MU", name: "Micron" },
  { symbol: "GILD", name: "Gilead Sciences" },
  { symbol: "GTLB", name: "GitLab" },
  { symbol: "ISRG", name: "Intuitive Surgical" },
  { symbol: "LRCX", name: "Lam Research" },
  { symbol: "PANW", name: "Palo Alto Networks" },
  { symbol: "MAR", name: "Marriott" },
  { symbol: "CDNS", name: "Cadence" },
  { symbol: "MELI", name: "MercadoLibre" },
  { symbol: "REGN", name: "Regeneron" },
  { symbol: "VRTX", name: "Vertex Pharm" },
];

// List 2 - alternate universe of 35 tickers
export const TICKERS2 = [
  { symbol: "ASML", name: "ASML Holding" },
  { symbol: "AZN", name: "AstraZeneca" },
  { symbol: "BIIB", name: "Biogen" },
  { symbol: "MRVL", name: "Marvell Tech" },
  { symbol: "CHTR", name: "Charter Comms" },
  { symbol: "CPRT", name: "Copart" },
  { symbol: "AMR", name: "AMR" },
  { symbol: "CSX", name: "CSX Corp" },
  { symbol: "CEG", name: "Constellation Energy" },
  { symbol: "DDOG", name: "Datadog" },
  { symbol: "DLTR", name: "Dollar Tree" },
  { symbol: "DXCM", name: "Dexcom" },
  { symbol: "LITE", name: "Lumentum" },
  { symbol: "EXC", name: "Exelon" },
  { symbol: "FAST", name: "Fastenal" },
  { symbol: "OKTA", name: "Okta" },
  { symbol: "IDXX", name: "IDEXX Labs" },
  { symbol: "KDP", name: "Keurig Dr Pepper" },
  { symbol: "KLAC", name: "KLA Corp" },
  { symbol: "TTWO", name: "Take-Two" },
  { symbol: "CRWV", name: "CoreWeave" },
  { symbol: "MCHP", name: "Microchip Tech" },
  { symbol: "MDLZ", name: "Mondelez" },
  { symbol: "MDB", name: "MongoDB" },
  { symbol: "NXPI", name: "NXP Semi" },
  { symbol: "ODFL", name: "Old Dominion" },
  { symbol: "ORLY", name: "O'Reilly" },
  { symbol: "PAYX", name: "Paychex" },
  { symbol: "PDD", name: "Pinduoduo" },
  { symbol: "ROST", name: "Ross Stores" },
  { symbol: "ROKU", name: "Roku" },
  { symbol: "VRSK", name: "Verisk" },
  { symbol: "WDAY", name: "Workday" },
  { symbol: "XEL", name: "Xcel Energy" },
  { symbol: "ZS", name: "Zscaler" },
];

export const TIMEFRAMES = {
  "15": "15Min",
  "30": "30Min",
  "60": "1Hour",
  "120": "2Hour",
  "240": "4Hour",
  "D": "1Day",
  "W": "1Week",
};

export function barsStartIso(tfKey, barsCount) {
  const now = Date.now();
  let days;
  if (tfKey === "W") days = barsCount * 7 + 10;
  else if (tfKey === "D") days = Math.ceil(barsCount * 1.5) + 5;
  else {
    const tradingDays = Math.ceil((barsCount * parseInt(tfKey, 10)) / 390);
    days = Math.ceil(tradingDays * 1.6) + 3;
  }
  return new Date(now - days * 86400000).toISOString();
}

// Newest bars first (sort=desc) so pagination always lands on recent data,
// returned chronologically (oldest -> newest)
// API keys whose plan can't read SIP data (free accounts) - skip that wasted request next time
const SIP_DENIED = new Set<string>();
const BAR_CACHE = new Map<string, { bars: any[]; updatedAt: number }>();
const CACHE_TTL_MS = { D: 4 * 60 * 60 * 1000, W: 12 * 60 * 60 * 1000 };
const timeframeMs = (tfKey: string) => {
  if (tfKey === "D") return 24 * 60 * 60 * 1000;
  if (tfKey === "W") return 7 * 24 * 60 * 60 * 1000;
  return Number(tfKey) * 60 * 1000;
};
function mergeBars(oldBars: any[], newBars: any[], maxBars: number) {
  const byTime = new Map<string, any>();
  for (const bar of [...oldBars, ...newBars]) byTime.set(bar.t, bar);
  return [...byTime.values()]
    .sort((a, b) => new Date(a.t).getTime() - new Date(b.t).getTime())
    .slice(-maxBars);
}

async function fetchFeed(symbol, timeframe, start, feed, apiKey, secretKey, minBars) {
  const collected = [];
  let token = null;
  let pages = 0;
  do {
    const url = `https://data.alpaca.markets/v2/stocks/${symbol}/bars?timeframe=${timeframe}&start=${start}&limit=10000&adjustment=raw&feed=${feed}&sort=desc${token ? `&page_token=${token}` : ""}`;
    let res = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      res = await fetch(url, {
        headers: { "APCA-API-KEY-ID": apiKey, "APCA-API-SECRET-KEY": secretKey },
      });
      if (res.ok || res.status === 404) break;
      // auth / plan errors never get better by retrying - fail fast
      if (res.status === 401 || res.status === 403 || res.status === 422) {
        if (feed === "sip") SIP_DENIED.add(apiKey);
        return collected.length ? collected.reverse() : null;
      }
      await new Promise((r) => setTimeout(r, 250 * (attempt + 1)));
    }
    if (res.status === 404) break;
    if (!res.ok) return collected.length ? collected.reverse() : null;
    const data = await res.json();
    for (const b of data.bars || []) {
      collected.push({ o: b.o, h: b.h, l: b.l, c: b.c, v: b.v, t: b.t });
    }
    token = data.next_page_token || null;
    pages++;
  } while (token && pages < 8 && (!minBars || collected.length < minBars));
  return collected.reverse();
}

export async function fetchBars(symbol, tfKey, barsCount, apiKey, secretKey) {
  const timeframe = TIMEFRAMES[tfKey];
  const cacheKey = `${apiKey}:${symbol}:${tfKey}`;
  const cached = BAR_CACHE.get(cacheKey);
  const now = Date.now();
  const ttl = CACHE_TTL_MS[tfKey] || 30 * 1000;
  const hasEnoughCached = cached && cached.bars.length >= barsCount;
  if (hasEnoughCached && now - cached.updatedAt < ttl) {
    return cached.bars.slice(-barsCount);
  }
  const incrementalStart = cached?.bars.length
    ? new Date(new Date(cached.bars[cached.bars.length - 1].t).getTime() - timeframeMs(tfKey)).toISOString()
    : null;
  const start = hasEnoughCached && incrementalStart ? incrementalStart : barsStartIso(tfKey, barsCount);
  let bars = SIP_DENIED.has(apiKey)
    ? []
    : await fetchFeed(symbol, timeframe, start, "sip", apiKey, secretKey, barsCount);
  if (bars === null) bars = [];
  // SIP can return delayed intraday bars - if they lag, try IEX and keep the fresher feed
  const isIntraday = tfKey !== "D" && tfKey !== "W";
  const lastT = bars.length ? new Date(bars[bars.length - 1].t).getTime() : 0;
  const sipStale = bars.length === 0 || (isIntraday && Date.now() - lastT > 10 * 60000);
  if (sipStale) {
    const iex = await fetchFeed(symbol, timeframe, start, "iex", apiKey, secretKey, barsCount);
    if (iex && iex.length) {
      const iexT = new Date(iex[iex.length - 1].t).getTime();
      if (iexT > lastT) bars = iex;
    }
  }
  const merged = cached && hasEnoughCached
    ? mergeBars(cached.bars, bars, Math.max(barsCount, cached.bars.length))
    : bars;
  BAR_CACHE.set(cacheKey, { bars: merged, updatedAt: now });
  return merged.slice(-barsCount);
}

// ---------- Indicator helpers (arrays are oldest -> newest) ----------

export function sumRange(arr, start, end) {
  let total = 0;
  for (let i = start; i <= end; i++) total += arr[i];
  return total;
}

export function smaAt(values, end, len) {
  if (end - len + 1 < 0) return null;
  return sumRange(values, end - len + 1, end) / len;
}

export function winMax(values, end, len) {
  if (end - len + 1 < 0) return null;
  let max = -Infinity;
  for (let i = end - len + 1; i <= end; i++) {
    if (values[i] > max) max = values[i];
  }
  return max;
}

export function winMin(values, end, len) {
  if (end - len + 1 < 0) return null;
  let min = Infinity;
  for (let i = end - len + 1; i <= end; i++) {
    if (values[i] < min) min = values[i];
  }
  return min;
}

export function stdevAt(values, end, len) {
  if (end - len + 1 < 0) return null;
  const mean = sumRange(values, end - len + 1, end) / len;
  let total = 0;
  for (let i = end - len + 1; i <= end; i++) {
    total += (values[i] - mean) * (values[i] - mean);
  }
  return Math.sqrt(total / len);
}

export function emaArr(values, len) {
  const out = new Array(values.length).fill(null);
  const k = 2 / (len + 1);
  let prev = null;
  for (let i = 0; i < values.length; i++) {
    if (i === len - 1) {
      prev = sumRange(values, 0, len - 1) / len;
      out[i] = prev;
    } else if (i >= len) {
      prev = values[i] * k + prev * (1 - k);
      out[i] = prev;
    }
  }
  return out;
}

export function rsiArr(values, len) {
  const out = new Array(values.length).fill(null);
  let avgGain = null;
  let avgLoss = null;
  for (let i = 1; i < values.length; i++) {
    const gain = Math.max(values[i] - values[i - 1], 0);
    const loss = Math.max(values[i - 1] - values[i], 0);
    if (i === len) {
      avgGain = 0;
      avgLoss = 0;
      for (let j = 1; j <= len; j++) {
        avgGain += Math.max(values[j] - values[j - 1], 0);
        avgLoss += Math.max(values[j - 1] - values[j], 0);
      }
      avgGain /= len;
      avgLoss /= len;
    } else if (i > len) {
      avgGain = (avgGain * (len - 1) + gain) / len;
      avgLoss = (avgLoss * (len - 1) + loss) / len;
    }
    if (i >= len) {
      out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
    }
  }
  return out;
}

export function atrArr(highs, lows, closes, len) {
  const n = closes.length;
  const out = new Array(n).fill(null);
  const tr = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    tr[i] = i === 0
      ? highs[0] - lows[0]
      : Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]));
  }
  let prev = null;
  for (let i = len - 1; i < n; i++) {
    if (i === len - 1) {
      let s = 0;
      for (let j = 0; j <= len - 1; j++) s += tr[j];
      prev = s / len;
    } else {
      prev = (prev * (len - 1) + tr[i]) / len;
    }
    out[i] = prev;
  }
  return out;
}

export function linregAtWindow(values, len, end) {
  if (end - len + 1 < 0) return null;
  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumX2 = 0;
  for (let k = 0; k < len; k++) {
    const y = values[end - len + 1 + k];
    sumX += k;
    sumY += y;
    sumXY += k * y;
    sumX2 += k * k;
  }
  const denom = len * sumX2 - sumX * sumX;
  const slope = denom === 0 ? 0 : (len * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / len;
  return intercept + slope * (len - 1);
}
