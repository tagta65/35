import { getKeys } from "../shared/keys.ts";
import { TIMEFRAMES, fetchBars } from "../shared/market.ts";
import { BARS_NEEDED } from "../shared/scanAlgos.ts";

const ALGOS = [
  { id: "p402", label: "Protocol 402 + Supply Squeeze" },
  { id: "vixfix", label: "Vix Fix + Momentum + RSI" },
  { id: "analog", label: "Analog UP + MTF" },
  { id: "smc", label: "Algorithm 4 · SMC" },
  { id: "orderflow", label: "Order Flow V2" },
];

const TF_CHECKS = [
  { tf: "15", label: "15 דק'" },
  { tf: "60", label: "שעה" },
  { tf: "D", label: "יומי" },
];

const SAMPLES = ["AAPL", "MSFT", "NVDA"];

function ageMin(iso) {
  if (!iso) return null;
  return Math.round((Date.now() - new Date(iso).getTime()) / 60000);
}

async function alpacaGet(path, apiKey, secretKey) {
  return fetch(`https://data.alpaca.markets${path}`, {
    headers: { "APCA-API-KEY-ID": apiKey, "APCA-API-SECRET-KEY": secretKey },
  });
}

async function lastBarCheck(symbol, tfKey, apiKey, secretKey, feed) {
  const start = new Date(Date.now() - 35 * 86400000).toISOString();
  const tf = TIMEFRAMES[tfKey];
  try {
    const res = await alpacaGet(
      `/v2/stocks/${symbol}/bars?timeframe=${tf}&start=${start}&limit=1000&adjustment=raw&feed=${feed}`,
      apiKey,
      secretKey
    );
    if (!res.ok) return { bars: 0, lastIso: null, error: `HTTP ${res.status}` };
    const data = await res.json();
    const bars = data.bars || [];
    return { bars: bars.length, lastIso: bars.length ? bars[bars.length - 1].t : null, error: null };
  } catch (err) {
    return { bars: 0, lastIso: null, error: err.message };
  }
}

export default async function (req: Request) {
  try {
    const checkedAt = new Date().toISOString();

    // 1) Keys come from the visitor's browser
    const { apiKey, secretKey } = getKeys(req);
    const keySource = "saved";

    if (!apiKey || !secretKey) {
      return Response.json({
        keys: { ok: false, source: null },
        connectivity: { ok: false, error: "חסרים מפתחות בורסה" },
        timeframes: [],
        algos: [],
        checkedAt,
      });
    }

    // 2) Realtime feed check - 1-minute bars, sip then iex
    let feed = null;
    let lastIso = null;
    let feedError = null;
    const start = new Date(Date.now() - 4 * 86400000).toISOString();
    for (const f of ["sip", "iex"]) {
      try {
        const res = await alpacaGet(
          `/v2/stocks/AAPL/bars?timeframe=1Min&start=${start}&limit=1&adjustment=raw&feed=${f}&sort=desc`,
          apiKey,
          secretKey
        );
        if (res.ok) {
          const data = await res.json();
          const bars = data.bars || [];
          if (bars.length) {
            feed = f;
            lastIso = bars[0].t;
            break;
          }
        } else {
          feedError = `HTTP ${res.status} (${f})`;
        }
      } catch (err) {
        feedError = err.message;
      }
    }

    // 3) Per-timeframe data freshness on sample symbols
    const activeFeed = feed || "iex";
    const timeframes = await Promise.all(TF_CHECKS.map(async ({ tf, label }) => {
      const samples = await Promise.all(SAMPLES.map(async (symbol) => {
        const chk = await lastBarCheck(symbol, tf, apiKey, secretKey, activeFeed);
        return { symbol, bars: chk.bars, lastIso: chk.lastIso, ageMin: ageMin(chk.lastIso), error: chk.error };
      }));
      return { tf, label, samples };
    }));

    // 4) Algo data availability (daily bars)
    let dailyAvailable = 0;
    try {
      const dailyBars = await fetchBars("AAPL", "D", 320, apiKey, secretKey);
      dailyAvailable = dailyBars.length;
    } catch (err) {
      dailyAvailable = 0;
    }
    const algos = ALGOS.map((a) => ({
      ...a,
      needed: BARS_NEEDED[a.id],
      available: dailyAvailable,
      ok: dailyAvailable >= BARS_NEEDED[a.id],
    }));

    return Response.json({
      keys: { ok: true, source: keySource },
      connectivity: {
        ok: feed !== null,
        feed,
        lastBarIso: lastIso,
        ageMin: ageMin(lastIso),
        error: feed === null ? (feedError || "לא נמצאו נרות דקה בשני הפידים") : null,
      },
      timeframes,
      algos,
      checkedAt,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}