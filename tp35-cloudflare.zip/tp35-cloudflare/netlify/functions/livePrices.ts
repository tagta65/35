// Lightweight live-prices endpoint: one batch call for all tickers.
import { getKeys, MISSING_KEYS } from "../shared/keys.ts";

export default async function (req: Request) {
  try {
    const { apiKey, secretKey } = getKeys(req);
    if (!apiKey || !secretKey) return Response.json({ error: MISSING_KEYS }, { status: 400 });

    const body: any = await req.json().catch(() => ({}));
    const list = Array.isArray(body.symbols) ? body.symbols : [];
    const symbols = list.filter((s: any) => typeof s === "string" && /^[A-Za-z.\-]{1,10}$/.test(s)).join(",");
    if (!symbols) return Response.json({ prices: {}, ts: new Date().toISOString() });

    const res = await fetch(
      `https://data.alpaca.markets/v2/stocks/trades/latest?symbols=${symbols}&feed=iex`,
      { headers: { "APCA-API-KEY-ID": apiKey, "APCA-API-SECRET-KEY": secretKey } }
    );
    if (!res.ok) return Response.json({ error: `Alpaca ${res.status}` }, { status: 502 });

    const data: any = await res.json();
    const prices: Record<string, number> = {};
    for (const [sym, trade] of Object.entries<any>(data.trades || {})) {
      if (trade && trade.p) prices[sym] = trade.p;
    }
    return Response.json({ prices, ts: new Date().toISOString() });
  } catch (error: any) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
